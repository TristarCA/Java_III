package Assignment1;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Author {
    private String firstName;
    private String lastName;
    private List<Book> titles;

    public Author(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.titles = new ArrayList<>();
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<Book> getTitles() {
        return titles;
    }

    public void addTitle(Book book) {
        if (!titles.contains(book)) {
            titles.add(book);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Author author = (Author) o;
        return Objects.equals(firstName.toLowerCase().trim(), author.firstName.toLowerCase().trim()) &&
                Objects.equals(lastName.toLowerCase().trim(), author.lastName.toLowerCase().trim());
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName.toLowerCase().trim(), lastName.toLowerCase().trim());
    }
}
