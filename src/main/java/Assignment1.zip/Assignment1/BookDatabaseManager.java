package Assignment1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This is the first example involving queries in the Objective 2 notes.
 */
public class BookDatabaseManager {
    public static final String DB_NAME = "/books";
    public static void AddBook(Book book) {
        try {
            Connection conn = DriverManager.getConnection(
                    Assignment1DBProperties.DATABASE_URL + DB_NAME,
                    Assignment1DBProperties.DATABASE_USER,
                    Assignment1DBProperties.DATABASE_PASSWORD);

            Statement stmt = conn.createStatement();

            // Check if the book already exists using the ISBN
            String checkBookExists = "SELECT COUNT(*) FROM titles WHERE isbn = '" + book.getISBN() + "'";
            ResultSet rs = stmt.executeQuery(checkBookExists);
            rs.next();
            int bookCount = rs.getInt(1);

            if (bookCount > 0) {
                System.out.println("Book already exists in the database.");
            } else {
                // Book doesn't exist, insert it
                String insertBook = "INSERT INTO titles (isbn, title, editionNumber, copyright) " +
                        "VALUES ('" + book.getISBN() + "', '" + book.getTitle() + "', " +
                        book.getEdition() + ", " + book.getCopyright() + ")";
                stmt.executeUpdate(insertBook);
                System.out.println("Book added successfully.");
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public static void AddAuthor(Author author) {
        try {
            Connection conn = DriverManager.getConnection(
                    Assignment1DBProperties.DATABASE_URL + DB_NAME, Assignment1DBProperties.DATABASE_USER, Assignment1DBProperties.DATABASE_PASSWORD);
            Statement stmt = conn.createStatement();
            final String INSERT_STATEMENT = "INSERT INTO authors (firstName, lastName) VALUES ('" + author.getFirstName() + "', '" + author.getLastName() + "')";
            stmt.executeUpdate(INSERT_STATEMENT);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void DeleteBook(Book book) {
        try {
            Connection conn = DriverManager.getConnection(
                    Assignment1DBProperties.DATABASE_URL + DB_NAME, Assignment1DBProperties.DATABASE_USER, Assignment1DBProperties.DATABASE_PASSWORD);
            Statement stmt = conn.createStatement();

            // First, delete the relation from the authorisbn table
            final String DELETE_RELATION_STATEMENT = "DELETE FROM authorisbn WHERE isbn = '" + book.getISBN() + "'";
            stmt.executeUpdate(DELETE_RELATION_STATEMENT);

            // Now, delete the book from the titles table
            final String DELETE_BOOK_STATEMENT = "DELETE FROM titles WHERE isbn = '" + book.getISBN() + "'";
            stmt.executeUpdate(DELETE_BOOK_STATEMENT);

            stmt.close();
            conn.close();

            System.out.println("Book and its relations have been deleted.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static List<Book> GetAllBooks() {
        List<Book> bookList = new ArrayList<>();  // Create a list to store the books

        try {
            Connection conn = DriverManager.getConnection(
                    Assignment1DBProperties.DATABASE_URL + DB_NAME,
                    Assignment1DBProperties.DATABASE_USER,
                    Assignment1DBProperties.DATABASE_PASSWORD);
            Statement stmt = conn.createStatement();

            final String SELECT_STATEMENT = "SELECT * FROM titles";
            ResultSet rs = stmt.executeQuery(SELECT_STATEMENT);

            while (rs.next()) {
                String isbn = rs.getString("isbn");
                String bookTitle = rs.getString("title");
                String bookEdition = rs.getString("editionNumber");
                String bookCopyright = rs.getString("copyright");

                Book book = new Book(isbn, bookTitle, Integer.parseInt(bookEdition), Integer.parseInt(bookCopyright));

                // Step 3: Get the authors associated with this book using the authorisbn table
                final String FIND_AUTHORS_STATEMENT = "SELECT authorID FROM authorisbn WHERE isbn = '" + isbn + "'";
                ResultSet rs2 = stmt.executeQuery(FIND_AUTHORS_STATEMENT);  // Use a regular Statement here

                while (rs2.next()) {
                    int authorID = rs2.getInt("authorID");

                    // Step 4: Get author details using the authorID
                    final String FIND_AUTHOR_DETAIL_STATEMENT = "SELECT * FROM authors WHERE authorID = " + authorID;
                    ResultSet rs3 = stmt.executeQuery(FIND_AUTHOR_DETAIL_STATEMENT);  // Again using regular Statement

                    if (rs3.next()) {
                        String authorFirstName = rs3.getString("firstName");
                        String authorLastName = rs3.getString("lastName");

                        // Create an Author object
                        Author author = new Author(authorFirstName, authorLastName);

                        // Add the author to the book's list of authors
                        book.addAuthor(author);  // Add this author to the book's authors list
                    }

                    rs3.close();
                }

                // Add the book to the list
                bookList.add(book);

                rs2.close();
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bookList;
    }


    public static List<Author> GetAllAuthors() {
        List<Author> authorList = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection(
                    Assignment1DBProperties.DATABASE_URL + DB_NAME,
                    Assignment1DBProperties.DATABASE_USER,
                    Assignment1DBProperties.DATABASE_PASSWORD);

            Statement stmt = conn.createStatement();

            // Step 1: Get all authors
            String selectStatement = "SELECT * FROM authors";
            ResultSet rs = stmt.executeQuery(selectStatement);

            while (rs.next()) {
                String authorFirstName = rs.getString("firstName");
                String authorLastName = rs.getString("lastName");
                int authorID = rs.getInt("authorID");

                // Step 2: Get the books related to the authorID using authorisbn
                String findBooksStatement = "SELECT isbn FROM authorisbn WHERE authorID = " + authorID;
                Statement stmt2 = conn.createStatement();
                ResultSet rs2 = stmt2.executeQuery(findBooksStatement);

                List<Book> titles = new ArrayList<>();  // This will hold all books by the author

                while (rs2.next()) {
                    String isbn = rs2.getString("isbn");

                    // Step 3: Get book details using the isbn from titles table
                    String findBookDetailStatement = "SELECT * FROM titles WHERE isbn = '" + isbn + "'";
                    Statement stmt3 = conn.createStatement();
                    ResultSet rs3 = stmt3.executeQuery(findBookDetailStatement);

                    // If the book is found, create a Book object and add it to the titles list
                    if (rs3.next()) {
                        String bookTitle = rs3.getString("title");
                        int edition = rs3.getInt("editionNumber");
                        int copyright = rs3.getInt("copyright");

                        // Create a Book object
                        Book book = new Book(isbn, bookTitle, edition, copyright);
                        titles.add(book);  // Add the book to the list
                    }

                    rs3.close();
                    stmt3.close();
                }

                // Create an Author object and associate the titles list with it
                Author author = new Author(authorFirstName, authorLastName);
                for (Book book : titles) {
                    author.addTitle(book);  // Add each book to the author's titles list
                }

                authorList.add(author);  // Add the author to the authorList

                rs2.close();
                stmt2.close();
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return authorList;
    }




    public static void AddRelation(Book book, Author author) {
        try {
            Connection conn = DriverManager.getConnection(
                    Assignment1DBProperties.DATABASE_URL + DB_NAME,
                    Assignment1DBProperties.DATABASE_USER,
                    Assignment1DBProperties.DATABASE_PASSWORD);
            Statement stmt = conn.createStatement();

            // Check if the author exists
            String checkAuthorExists = "SELECT authorID FROM authors WHERE firstName = '" + author.getFirstName() +
                    "' AND lastName = '" + author.getLastName() + "'";
            ResultSet authorRs = stmt.executeQuery(checkAuthorExists);

            if (!authorRs.next()) {
                System.out.println("Author " + author.getFirstName() + " " + author.getLastName() + " does not exist. Cannot create relationship.");
                return;
            }
            int authorId = authorRs.getInt("authorID");

            // Check if the book exists
            String checkBookExists = "SELECT isbn FROM titles WHERE isbn = '" + book.getISBN() + "'";
            ResultSet bookRs = stmt.executeQuery(checkBookExists);

            if (!bookRs.next()) {
                System.out.println("Book with ISBN " + book.getISBN() + " does not exist. Cannot create relationship.");
                return;
            }

            // Create the relationship
            String insertRelation = "INSERT INTO authorisbn (authorID, isbn) VALUES (" + authorId + ", '" + book.getISBN() + "')";
            stmt.executeUpdate(insertRelation);
            System.out.println("Relationship between book " + book.getTitle() + " and author " + author.getFirstName() + " " + author.getLastName() + " created successfully.");

            // Close resources
            authorRs.close();
            bookRs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void UpdateBook(Book book) {
        try {
            Connection conn = DriverManager.getConnection(
                    Assignment1DBProperties.DATABASE_URL + DB_NAME,
                    Assignment1DBProperties.DATABASE_USER,
                    Assignment1DBProperties.DATABASE_PASSWORD);

            // Check if the book exists using the ISBN
            String checkBookExists = "SELECT COUNT(*) FROM titles WHERE isbn = '" + book.getISBN() + "'";
            Statement stmt1 = conn.createStatement();
            ResultSet rs = stmt1.executeQuery(checkBookExists);
            rs.next();
            int bookCount = rs.getInt(1);

            if (bookCount > 0) {
                // Book exists, update it
                String updateBook = "UPDATE titles SET title = '" + book.getTitle() + "', editionNumber = " + book.getEdition() +
                        ", copyright = " + book.getCopyright() + " WHERE isbn = '" + book.getISBN() + "'";
                Statement stmt2 = conn.createStatement();
                stmt2.executeUpdate(updateBook);
                System.out.println("Book with ISBN " + book.getISBN() + " successfully updated.");
            } else {
                // Book does not exist, throw an error or handle accordingly
                System.out.println("Book with ISBN " + book.getISBN() + " does not exist. Cannot update.");
            }

            // Close resources
            rs.close();
            stmt1.close();
            conn.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public static boolean UpdateAuthor(Author author, String originalFirstName, String originalLastName) {
        try {
            Connection conn = DriverManager.getConnection(
                    Assignment1DBProperties.DATABASE_URL + DB_NAME,
                    Assignment1DBProperties.DATABASE_USER,
                    Assignment1DBProperties.DATABASE_PASSWORD);
            Statement stmt = conn.createStatement();

            // Check if the original author exists
            String checkAuthorExists = "SELECT authorID FROM authors WHERE firstName = '" + originalFirstName +
                    "' AND lastName = '" + originalLastName + "'";
            ResultSet rs = stmt.executeQuery(checkAuthorExists);

            if (rs.next()) {
                int authorId = rs.getInt("authorID");
                // Update the existing author's name
                String updateAuthor = "UPDATE authors SET firstName = '" + author.getFirstName() +
                        "', lastName = '" + author.getLastName() + "' WHERE authorID = " + authorId;
                int rowsUpdated = stmt.executeUpdate(updateAuthor);
                if (rowsUpdated > 0) {
                    System.out.println("Author " + author.getFirstName() + " " + author.getLastName() + " successfully updated.");
                    return true;
                } else {
                    System.out.println("No rows updated. Author may not exist.");
                    return false;
                }
            } else {
                // Author does not exist, cannot update
                System.out.println("Author " + originalFirstName + " " + originalLastName + " does not exist. Cannot update.");
                return false;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }



}