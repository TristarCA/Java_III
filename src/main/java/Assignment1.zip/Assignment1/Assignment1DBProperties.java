package Assignment1;

public class Assignment1DBProperties {

    public static final String DATABASE_URL = "jdbc:mariadb://localhost:3300";

    public static final String DATABASE_USER = "root";

    public static final String DATABASE_PASSWORD = "root";

}
