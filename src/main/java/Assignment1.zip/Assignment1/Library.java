package Assignment1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Library {
    private List<Book> books;
    private List<Author> authors;

    public Library() {
        books = BookDatabaseManager.GetAllBooks();
        authors = BookDatabaseManager.GetAllAuthors();
    }

    public List<Book> getBooks() {
        return books;
    }

    public Book getBook(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public List<Author> getAuthors() {
        return authors;
    }

    public void addBook(Book book) {
        if (!books.contains(book)) {
            BookDatabaseManager.AddBook(book);
            books.add(book);
        }
    }

    public void addAuthor(Author author) {
        if (!authors.contains(author)) {
            BookDatabaseManager.AddAuthor(author);
            authors.add(author);
        }
    }

    public void printBooksByAuthor(String authorFullName) {
        String[] nameParts = authorFullName.split(" ");
        if (nameParts.length == 2) {
            String firstName = nameParts[0];
            String lastName = nameParts[1];
            Author foundAuthor = null;
            for (Author author : authors) {
                if (author.getFirstName().equalsIgnoreCase(firstName) &&
                        author.getLastName().equalsIgnoreCase(lastName)) {
                    foundAuthor = author;
                    break;
                }
            }
            if (foundAuthor != null) {
                System.out.println("Books by " + firstName + " " + lastName + ":");
                for (Book book : foundAuthor.getTitles()) {
                    System.out.println(" - " + book.getTitle() + " (ISBN: " + book.getISBN() + ")");
                }
            } else {
                System.out.println("Author not found.");
            }
        } else {
            System.out.println("Please provide both first and last name of the author.");
        }
    }

    public Book getBookByISBN(String isbn) {
        for (Book book : books) {
            if (book.getISBN().equals(isbn)) {
                return book;
            }
        }
        return null;
    }


    public void addNewBookAndAuthor(String newBookTitle, String newISBN, int newEdition, int newCopyrightYear,
                                    String newAuthorFirstName, String newAuthorLastName) {
        // Check for existing author first
        Author existingAuthor = null;
        for (Author a : authors) {
            if (a.getFirstName().equalsIgnoreCase(newAuthorFirstName) && a.getLastName().equalsIgnoreCase(newAuthorLastName)) {
                existingAuthor = a;
                break;
            }
        }

        // Check for existing book by ISBN
        Book existingBook = getBookByISBN(newISBN);  // Ensure this method checks by ISBN, not title

        // Decide the action based on existing author and book
        if (existingBook != null && existingAuthor != null) {
            // Both exist
            if (!existingBook.getAuthors().contains(existingAuthor)) {
                existingBook.addAuthor(existingAuthor);
                existingAuthor.addTitle(existingBook);
                BookDatabaseManager.AddRelation(existingBook, existingAuthor);
                System.out.println("Existing book updated with new author.");
            } else {
                System.out.println("This book and author combination already exists.");
            }
        } else if (existingBook == null && existingAuthor != null) {
            // New book, existing author
            Book newBook = new Book(newISBN, newBookTitle, newEdition, newCopyrightYear);
            newBook.addAuthor(existingAuthor);
            existingAuthor.addTitle(newBook);
            addBook(newBook);  // Ensures new book is added to the database
            BookDatabaseManager.AddRelation(newBook, existingAuthor);
            System.out.println("New book added for existing author.");
        } else if (existingBook != null && existingAuthor == null) {
            // Existing book, new author
            Author newAuthor = new Author(newAuthorFirstName, newAuthorLastName);
            existingBook.addAuthor(newAuthor);
            newAuthor.addTitle(existingBook);
            addAuthor(newAuthor);  // Ensures new author is added to the database
            BookDatabaseManager.AddRelation(existingBook, newAuthor);
            System.out.println("Existing book updated with new author.");
        } else {
            // Both are new
            Book newBook = new Book(newISBN, newBookTitle, newEdition, newCopyrightYear);
            Author newAuthor = new Author(newAuthorFirstName, newAuthorLastName);
            newBook.addAuthor(newAuthor);
            newAuthor.addTitle(newBook);
            addBook(newBook);  // Adds new book to the database
            addAuthor(newAuthor);  // Adds new author to the database
            BookDatabaseManager.AddRelation(newBook, newAuthor);
            System.out.println("New book and author added successfully.");
        }
    }


    public void removeBookByTitle(String removeTitle) {
        Book bookToRemove = getBook(removeTitle);
        if (bookToRemove != null) {
            System.out.println("Please enter the author's name for the book:");
            Scanner input = new Scanner(System.in);
            String removeAuthorSearch = input.nextLine();

            String[] removeAuthorNameParts = removeAuthorSearch.split(" ");
            if (removeAuthorNameParts.length == 2) {
                String removeFirstName = removeAuthorNameParts[0];
                String removeLastName = removeAuthorNameParts[1];

                Author removeAuthor = null;
                for (Author a : authors) {
                    if (a.getFirstName().equalsIgnoreCase(removeFirstName) &&
                            a.getLastName().equalsIgnoreCase(removeLastName)) {
                        removeAuthor = a;
                        break;
                    }
                }

                if (removeAuthor != null) {
                    if (removeAuthor.getTitles().contains(bookToRemove)) {
                        removeAuthor.getTitles().remove(bookToRemove);
                        BookDatabaseManager.DeleteBook(bookToRemove);
                        books.remove(bookToRemove);
                        System.out.println(removeTitle + " successfully removed from the library!");
                    } else {
                        System.out.println("The book is not associated with the author " + removeFirstName + " " + removeLastName);
                    }
                } else {
                    System.out.println("Author not found.");
                }
            } else {
                System.out.println("Please enter both first and last name of the author.");
            }
        } else {
            System.out.println("This book does not exist in the library.");
        }
    }

    public void editBookDetails(String isbn, Scanner input) {
        Book bookToEdit = getBookByISBN(isbn);
        if (bookToEdit != null) {
            System.out.println("Enter new title (leave blank to keep the current title):");
            String newTitle = input.nextLine().trim();
            System.out.println("Enter new edition number (leave blank to keep the current edition):");
            String updatedEdition = input.nextLine().trim();
            System.out.println("Enter new copyright year (leave blank to keep the current year):");
            String newCopyright = input.nextLine().trim();

            boolean updated = false;
            if (!newTitle.isEmpty() && !newTitle.equals(bookToEdit.getTitle())) {
                bookToEdit.setTitle(newTitle);
                updated = true;
            }
            if (!updatedEdition.isEmpty()) {
                try {
                    int edition = Integer.parseInt(updatedEdition);
                    if (edition != bookToEdit.getEdition()) {
                        bookToEdit.setEdition(edition);
                        updated = true;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid edition number format.");
                }
            }
            if (!newCopyright.isEmpty()) {
                try {
                    int copyright = Integer.parseInt(newCopyright);
                    if (copyright != bookToEdit.getCopyright()) {
                        bookToEdit.setCopyright(copyright);
                        updated = true;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid copyright year format.");
                }
            }

            if (updated) {
                BookDatabaseManager.UpdateBook(bookToEdit);
                System.out.println("Book details updated!");
            } else {
                System.out.println("No changes made to the book.");
            }
        } else {
            System.out.println("Book with the specified ISBN not found.");
        }
    }

    public void editAuthorDetails(String authorFullName, Scanner input) {
        authorFullName = authorFullName.trim();
        String[] nameParts = authorFullName.split(" ");
        if (nameParts.length == 2) {
            String firstName = nameParts[0].trim();
            String lastName = nameParts[1].trim();

            Author authorToEdit = null;
            for (Author author : authors) {
                if (author.getFirstName().equalsIgnoreCase(firstName) &&
                        author.getLastName().equalsIgnoreCase(lastName)) {
                    authorToEdit = author;
                    break;
                }
            }

            if (authorToEdit != null) {
                System.out.println("Enter new first name (leave blank to keep the current first name):");
                String newFirstName = input.nextLine().trim();
                System.out.println("Enter new last name (leave blank to keep the current last name):");
                String newLastName = input.nextLine().trim();

                boolean updated = false;
                if (!newFirstName.isEmpty() && !newFirstName.equalsIgnoreCase(authorToEdit.getFirstName())) {
                    authorToEdit.setFirstName(newFirstName);
                    updated = true;
                }
                if (!newLastName.isEmpty() && !newLastName.equalsIgnoreCase(authorToEdit.getLastName())) {
                    authorToEdit.setLastName(newLastName);
                    updated = true;
                }

                if (updated) {
                    boolean updateSuccess = BookDatabaseManager.UpdateAuthor(authorToEdit, firstName, lastName);
                    if (updateSuccess) {
                        // Refresh the in-memory lists to reflect the changes
                        refreshLists();
                        System.out.println("Author details updated!");
                    } else {
                        System.out.println("Failed to update author details in the database.");
                    }
                } else {
                    System.out.println("No changes made.");
                }
            } else {
                System.out.println("Author not found. Please check the spelling and try again.");
            }
        } else {
            System.out.println("Please provide both first and last name.");
        }
    }

    // Helper method to refresh in-memory data
    private void refreshLists() {
        books = BookDatabaseManager.GetAllBooks();
        authors = BookDatabaseManager.GetAllAuthors();
    }

    public void printAllBooks() {
        for (Book book : books) {
            System.out.println("\n" + book.getTitle() + " by:");
            List<Author> authors = book.getAuthors();
            if (authors.isEmpty()) {
                System.out.println("No authors listed.");
            } else {
                for (Author author : authors) {
                    System.out.println(" - " + author.getFirstName() + " " + author.getLastName());
                }
            }
        }
    }

    public void printAllAuthors() {
        for (Author author : authors) {
            System.out.println("\n" + author.getFirstName() + " " + author.getLastName() + ":");
            List<Book> books = author.getTitles();
            if (books.isEmpty()) {
                System.out.println("No books listed.");
            } else {
                for (Book book : books) {
                    System.out.println(" - " + book.getTitle());
                }
            }
        }
    }
}
